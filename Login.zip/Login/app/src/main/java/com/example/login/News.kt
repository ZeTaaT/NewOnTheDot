package com.example.login

data class News (
    val title : String?,
    val source : String?,
    val url : String?,
    val imageUrl : String?
    ){

}