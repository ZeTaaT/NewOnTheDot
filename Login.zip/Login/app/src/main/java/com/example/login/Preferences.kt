package com.example.login

import androidx.appcompat.app.AppCompatActivity

class Preferences : AppCompatActivity() {

}